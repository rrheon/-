//
//  CommentDetailVC.swift
//  week-10
//
//  Created by 최용헌 on 12/18/24.
//

import UIKit

class CommentDetailVC: UIViewController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
  }
}

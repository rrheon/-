//
//  ViewController.swift
//  week-10
//
//  Created by 최용헌 on 12/17/24.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}

